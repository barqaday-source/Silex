import { createFileRoute } from "@tanstack/react-router";
import {
  Bell,
  ChevronLeft,
  ChevronRight,
  CirclePlus,
  Clock3,
  Grid3X3,
  Heart,
  Home,
  Image,
  Loader2,
  LogOut,
  MapPin,
  MessageCircle,
  Mic,
  MoreHorizontal,
  Package,
  Search,
  Send,
  Share2,
  ShoppingBag,
  SlidersHorizontal,
  Sparkles,
  Store,
  Tag,
  UserRound,
  UsersRound,
  WalletCards,
  X,
} from "lucide-react";
import { useState } from "react";

import baghdad from "@/assets/baghdad.jpg";
import headphones from "@/assets/headphones.jpg";
import portrait from "@/assets/portrait.jpg";
import shoe from "@/assets/shoe.jpg";
import suv from "@/assets/suv.jpg";
import watch from "@/assets/watch.jpg";
import { AuthScreen } from "@/components/AuthScreen";
import { Button } from "@/components/ui/button";
import { AuthProvider, useAuth } from "@/hooks/useAuth";

export const Route = createFileRoute("/")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "تاجر — سوقك بلمسة واحدة" },
      { name: "description", content: "سجّل حسابك في تاجر واكتشف المنتجات والمتاجر والعروض القريبة منك." },
      { property: "og:title", content: "تاجر — سوقك بلمسة واحدة" },
      { property: "og:description", content: "تسوّق، بيع، وتواصل مع مجتمعك في مكان واحد." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: TaRoot,
});

type Tab = "home" | "search" | "sell" | "chat" | "profile";
type Product = { name: string; price: string; image: string; seller: string };

const products: Product[] = [
  { name: "حذاء رياضي", price: "75,000 د.ع", image: shoe, seller: "Nike Shoes" },
  { name: "ساعة ذكية", price: "350,000 د.ع", image: watch, seller: "Time House" },
  { name: "سماعة احترافية", price: "125,000 د.ع", image: headphones, seller: "Digital Store" },
  { name: "رينج روفر", price: "85,000,000 د.ع", image: suv, seller: "Baghdad Cars" },
];

const navItems: { id: Tab; label: string; icon: typeof Home }[] = [
  { id: "home", label: "الرئيسية", icon: Home },
  { id: "search", label: "استكشاف", icon: Search },
  { id: "sell", label: "بيع", icon: CirclePlus },
  { id: "chat", label: "الرسائل", icon: MessageCircle },
  { id: "profile", label: "حسابي", icon: UserRound },
];

function TaMark({ compact = false }: { compact?: boolean }) {
  return (
    <div className="flex items-center gap-2" aria-label="تاجر">
      <span className={compact ? "brand-mark brand-mark-sm" : "brand-mark"}>ت</span>
      {!compact && <strong className="text-xl font-extrabold text-foreground">تاجر</strong>}
    </div>
  );
}

function TopBar({ onSearch }: { onSearch: () => void }) {
  return (
    <header className="sticky top-0 z-30 border-b border-border/70 bg-background/90 px-4 pb-3 pt-4 backdrop-blur-xl">
      <div className="mx-auto flex max-w-6xl items-center gap-3">
        <TaMark />
        <button className="search-pill" onClick={onSearch} aria-label="البحث">
          <Search size={17} />
          <span>ابحث عن منتج أو متجر...</span>
        </button>
        <Button variant="ghost" size="icon" aria-label="الإشعارات" className="relative rounded-full">
          <Bell />
          <span className="absolute right-1 top-1 size-2 rounded-full bg-destructive" />
        </Button>
        <img src={portrait} alt="صورة Jude adaiy" className="size-9 rounded-full object-cover" width={38} height={38} />
      </div>
    </header>
  );
}

function BottomNav({ active, onChange }: { active: Tab; onChange: (tab: Tab) => void }) {
  return (
    <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-background/95 px-2 pb-[max(.55rem,env(safe-area-inset-bottom))] pt-2 backdrop-blur-xl lg:bottom-auto lg:left-0 lg:right-auto lg:top-0 lg:h-screen lg:w-24 lg:border-r lg:border-t-0 lg:px-3 lg:py-6">
      <div className="mx-auto flex max-w-xl items-center justify-around lg:h-full lg:flex-col lg:justify-start lg:gap-4">
        <div className="mb-5 hidden lg:block"><TaMark compact /></div>
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = active === item.id;
          return (
            <Button
              key={item.id}
              variant="ghost"
              onClick={() => onChange(item.id)}
              className={`nav-button ${isActive ? "nav-button-active" : ""} ${item.id === "sell" ? "nav-sell" : ""}`}
              aria-label={item.label}
            >
              <Icon />
              <span>{item.label}</span>
            </Button>
          );
        })}
      </div>
    </nav>
  );
}

function SectionTitle({ title, action }: { title: string; action?: string }) {
  return (
    <div className="mb-3 flex items-center justify-between">
      <h2 className="text-lg font-extrabold">{title}</h2>
      {action && <button className="flex items-center gap-1 text-xs font-bold text-primary">{action}<ChevronLeft size={15} /></button>}
    </div>
  );
}

function HomeScreen({ onStory, onProduct }: { onStory: () => void; onProduct: (p: Product) => void }) {
  const categories = [
    [ShoppingBag, "متاجر"], [Store, "ماركات"], [Tag, "عروض"], [UsersRound, "مجتمع"], [Grid3X3, "الكل"],
  ] as const;
  return (
    <main className="page-shell">
      <section className="offer-banner">
        <div className="relative z-10 max-w-[58%]">
          <span className="mb-2 inline-flex rounded-full bg-background/15 px-3 py-1 text-xs font-bold text-primary-foreground">خصم حصري</span>
          <h1 className="text-2xl font-black leading-tight text-primary-foreground">عروض حصرية<br />لهاتف أحلامك</h1>
          <Button size="sm" className="mt-3 bg-background text-primary shadow-none hover:bg-background/90">اكتشف الآن</Button>
        </div>
        <img src={portrait} alt="أحدث العروض" className="absolute inset-y-0 left-0 h-full w-[43%] object-cover object-top opacity-90" />
      </section>

      <div className="category-strip">
        {categories.map(([Icon, label]) => <button key={label} className="category-item"><span><Icon /></span><b>{label}</b></button>)}
      </div>

      <section className="content-section">
        <SectionTitle title="المواسم" action="مشاهدة الكل" />
        <button className="story-card" onClick={onStory}>
          <img src={baghdad} alt="بغداد في المساء" />
          <span><small>اكتشف</small><strong>ليالي بغداد</strong></span>
        </button>
      </section>

      <section className="content-section">
        <SectionTitle title="الأكثر تفاعلاً" action="المزيد" />
        <div className="product-grid">
          {products.map((product) => (
            <button key={product.name} className="product-card" onClick={() => onProduct(product)}>
              <div className="product-image-wrap"><img src={product.image} alt={product.name} loading="lazy" /><Heart className="heart" /></div>
              <div className="p-3 text-right"><p className="mb-1 text-xs text-muted-foreground">{product.seller}</p><h3>{product.name}</h3><strong>{product.price}</strong></div>
            </button>
          ))}
        </div>
      </section>
    </main>
  );
}

function SearchScreen({ onProduct }: { onProduct: (p: Product) => void }) {
  const [query, setQuery] = useState("");
  const visible = products.filter((p) => p.name.includes(query) || p.seller.toLowerCase().includes(query.toLowerCase()));
  return (
    <main className="page-shell">
      <div className="page-heading"><div><p>اكتشف الأفضل</p><h1>البحث</h1></div><Button variant="outline" size="icon" aria-label="ترتيب البحث"><SlidersHorizontal /></Button></div>
      <label className="input-pill"><Search /><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="شنو تدور اليوم؟" autoFocus /></label>
      <div className="chips"><button className="active">الكل</button><button>منتجات</button><button>متاجر</button><button>أشخاص</button></div>
      <SectionTitle title="النتائج المقترحة" />
      <div className="search-results">
        {visible.map((p) => <button key={p.name} className="result-row" onClick={() => onProduct(p)}><img src={p.image} alt={p.name} /><span><b>{p.name}</b><small>{p.seller}</small></span><strong>{p.price}</strong><ChevronLeft /></button>)}
        {!visible.length && <div className="empty-state"><Search /><b>لا توجد نتائج</b><span>جرّب كلمة بحث ثانية</span></div>}
      </div>
      <SectionTitle title="متاجر مميزة" action="مشاهدة الكل" />
      <div className="store-grid">{products.slice(0, 3).map((p) => <div key={p.seller}><img src={p.image} alt={p.seller} /><b>{p.seller}</b><small>متجر موثّق</small></div>)}</div>
    </main>
  );
}

function SellScreen() {
  const [mode, setMode] = useState<"sell" | "auction">("sell");
  const [imageAdded, setImageAdded] = useState(false);
  return (
    <main className="page-shell">
      <div className="page-heading"><div><p>خلّي بضاعتك توصل</p><h1>إضافة إعلان</h1></div><Package /></div>
      <div className="segmented"><button onClick={() => setMode("sell")} className={mode === "sell" ? "active" : ""}>بيع مباشر</button><button onClick={() => setMode("auction")} className={mode === "auction" ? "active" : ""}>مزاد</button></div>
      <button className={`upload-box ${imageAdded ? "has-image" : ""}`} onClick={() => setImageAdded(true)}>
        {imageAdded ? <img src={shoe} alt="صورة المنتج المضافة" /> : <><span><Image /></span><b>أضف صور المنتج</b><small>صورة واضحة تزيد فرصة البيع</small></>}
      </button>
      <div className="form-stack">
        <label><span>عنوان الإعلان</span><input placeholder="مثال: حذاء رياضي جديد" /></label>
        <label><span>{mode === "auction" ? "سعر بداية المزاد" : "السعر"}</span><div className="price-input"><input inputMode="numeric" placeholder="0" /><b>د.ع</b></div></label>
        <label><span>القسم</span><button className="select-row">اختر القسم <ChevronLeft /></button></label>
        <label><span>الوصف</span><textarea placeholder="اكتب تفاصيل المنتج وحالته..." rows={4} /></label>
      </div>
      <Button size="lg" className="mt-5 h-12 w-full rounded-xl text-base"><Sparkles />نشر الإعلان</Button>
    </main>
  );
}

function ChatScreen() {
  const [open, setOpen] = useState(false);
  const [sent, setSent] = useState(false);
  if (open) return (
    <main className="chat-page">
      <div className="chat-header"><Button variant="ghost" size="icon" onClick={() => setOpen(false)}><ChevronRight /></Button><img src={portrait} alt="أحمد علي" /><span><b>أحمد علي</b><small>متصل الآن</small></span><Button variant="ghost" size="icon"><MoreHorizontal /></Button></div>
      <div className="messages"><span className="date-chip">اليوم</span><p className="bubble other">هلا، المنتج بعده موجود؟<small>9:41</small></p><p className="bubble mine">هلا بيك، إي نعم موجود وبحالة جديدة<small>9:42</small></p><div className="chat-product"><img src={shoe} alt="الحذاء الرياضي" /><span><b>حذاء رياضي</b><small>75,000 د.ع</small></span></div>{sent && <p className="bubble mine">تمام، نتفق على التوصيل 👍<small>الآن</small></p>}</div>
      <div className="composer"><Button variant="ghost" size="icon"><CirclePlus /></Button><input placeholder="اكتب رسالة..." /><Button variant="ghost" size="icon"><Mic /></Button><Button size="icon" className="rounded-full" onClick={() => setSent(true)}><Send /></Button></div>
    </main>
  );
  return (
    <main className="page-shell">
      <div className="page-heading"><div><p>ابقَ على تواصل</p><h1>الرسائل</h1></div><Button variant="outline" size="icon"><MoreHorizontal /></Button></div>
      <label className="input-pill"><Search /><input placeholder="ابحث في المحادثات" /></label>
      {["أحمد علي", "Nike Shoes", "سارة محمد"].map((name, i) => <button key={name} className="conversation" onClick={() => setOpen(true)}><img src={i === 1 ? shoe : portrait} alt={name} /><span><b>{name}</b><small>{i === 0 ? "المنتج بعده موجود؟" : i === 1 ? "تم تجهيز طلبك للشحن" : "شكراً جزيلاً"}</small></span><time>{i === 0 ? "الآن" : "أمس"}</time>{i === 0 && <em>2</em>}</button>)}
    </main>
  );
}

function ProfileScreen({ onProduct }: { onProduct: (p: Product) => void }) {
  const { user, profile, signOut } = useAuth();
  const name = profile?.display_name || user?.email?.split("@")[0] || "مستخدم تاجر";
  const handle = profile?.username || user?.email?.split("@")[0] || "tajer";
  const avatar = profile?.avatar_url || portrait;
  return (
    <main className="profile-page">
      <div className="profile-cover"><img src={baghdad} alt="مدينة بغداد" /><div className="profile-actions"><Button variant="secondary" size="icon"><Share2 /></Button><Button variant="secondary" size="icon" aria-label="تسجيل الخروج" onClick={() => void signOut()}><LogOut /></Button></div></div>
      <section className="profile-info">
        <img src={avatar} alt={name} className="avatar-xl" />
        <h1>{name} <span>✓</span></h1><p>@{handle}</p><small><MapPin /> {profile?.city || "بغداد، العراق"}</small>
        <div className="stats"><div><b>124</b><span>المنشورات</span></div><div><b>2.4K</b><span>المتابعون</span></div><div><b>56</b><span>يتابع</span></div></div>
        <div className="profile-buttons"><Button variant="outline">تعديل الملف</Button><Button variant="ghost" onClick={() => void signOut()}><LogOut />تسجيل الخروج</Button></div>
      </section>
      <div className="profile-tabs"><button className="active"><Grid3X3 />المنشورات</button><button><ShoppingBag />المتجر</button><button><Heart />المفضلة</button></div>
      <div className="profile-grid">{[baghdad, suv, portrait, shoe, headphones, watch].map((img, i) => <button key={img} onClick={() => { const product = products[i % products.length]; if (product) onProduct(product); }}><img src={img} alt={`منشور ${i + 1}`} /></button>)}</div>
    </main>
  );
}

function Story({ onClose }: { onClose: () => void }) {
  return <div className="story-view"><img src={baghdad} alt="قصة بغداد" /><div className="story-progress"><i /></div><div className="story-user"><img src={portrait} alt="أحمد" /><span><b>ahmed.88</b><small>منذ ساعتين</small></span><Button variant="ghost" size="icon" onClick={onClose}><X /></Button></div><div className="story-caption"><h2>بغداد</h2><p><MapPin /> شارع الرشيد، بغداد</p></div><div className="story-reply"><input placeholder="إرسال رسالة..." /><Heart /><Send /></div></div>;
}

function ProductSheet({ product, onClose }: { product: Product; onClose: () => void }) {
  return <div className="modal-backdrop" onClick={onClose}><div className="product-sheet" onClick={(e) => e.stopPropagation()}><div className="sheet-handle" /><Button variant="secondary" size="icon" className="sheet-close" onClick={onClose}><X /></Button><img src={product.image} alt={product.name} className="sheet-image" /><div className="sheet-content"><div className="flex items-start justify-between"><div><small>{product.seller}</small><h2>{product.name}</h2></div><Button variant="outline" size="icon"><Heart /></Button></div><div className="rating">★★★★★ <span>4.9 (128 تقييم)</span></div><h3>{product.price}</h3><p>منتج أصلي بحالة ممتازة، متوفر للتوصيل داخل بغداد والمحافظات.</p><div className="delivery"><Clock3 /><span><b>توصيل سريع</b><small>خلال 24–48 ساعة</small></span></div><Button size="lg" className="h-12 w-full rounded-xl"><ShoppingBag />تواصل مع البائع</Button></div></div></div>;
}

function TaRoot() {
  return (
    <AuthProvider>
      <TaGate />
    </AuthProvider>
  );
}

function TaGate() {
  const { user, loading } = useAuth();
  if (loading) {
    return (
      <div dir="rtl" className="flex min-h-screen items-center justify-center bg-background text-foreground">
        <Loader2 className="animate-spin" />
      </div>
    );
  }
  if (!user) return <AuthScreen />;
  return <TaApp />;
}

function TaApp() {
  const [tab, setTab] = useState<Tab>("home");
  const [story, setStory] = useState(false);
  const [selected, setSelected] = useState<Product | null>(null);
  return (
    <div dir="rtl" className="min-h-screen bg-background font-sans text-foreground lg:pr-24">
      {tab !== "chat" && <TopBar onSearch={() => setTab("search")} />}
      {tab === "home" && <HomeScreen onStory={() => setStory(true)} onProduct={setSelected} />}
      {tab === "search" && <SearchScreen onProduct={setSelected} />}
      {tab === "sell" && <SellScreen />}
      {tab === "chat" && <ChatScreen />}
      {tab === "profile" && <ProfileScreen onProduct={setSelected} />}
      <BottomNav active={tab} onChange={setTab} />
      {story && <Story onClose={() => setStory(false)} />}
      {selected && <ProductSheet product={selected} onClose={() => setSelected(null)} />}
    </div>
  );
}