import { Loader2, Lock, Mail, UserRound } from "lucide-react";
import { useState } from "react";

import { Button } from "@/components/ui/button";
import { lovable } from "@/integrations/lovable/index";
import { supabase } from "@/integrations/supabase/client";

type Mode = "login" | "signup";

export function AuthScreen() {
  const [mode, setMode] = useState<Mode>("login");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setBusy(true);
    setError(null);
    try {
      if (mode === "signup") {
        const { error: signUpError } = await supabase.auth.signUp({
          email: email.trim(),
          password,
          options: {
            emailRedirectTo: window.location.origin,
            data: { display_name: name.trim() || email.split("@")[0] },
          },
        });
        if (signUpError) throw signUpError;
      } else {
        const { error: signInError } = await supabase.auth.signInWithPassword({
          email: email.trim(),
          password,
        });
        if (signInError) throw signInError;
      }
    } catch (caught) {
      const message = caught instanceof Error ? caught.message : "حدث خطأ غير متوقع";
      setError(
        /invalid login/i.test(message)
          ? "البريد الإلكتروني أو كلمة المرور غير صحيحة"
          : /already registered|already been/i.test(message)
            ? "هذا البريد مسجّل مسبقاً، جرّب تسجيل الدخول"
            : /password/i.test(message)
              ? "كلمة المرور يجب أن تكون 6 أحرف على الأقل"
              : message,
      );
    } finally {
      setBusy(false);
    }
  };

  const googleSignIn = async () => {
    setBusy(true);
    setError(null);
    const result = await lovable.auth.signInWithOAuth("google", {
      redirect_uri: window.location.origin,
    });
    if (result.error) {
      setError("تعذّر الدخول عبر جوجل، حاول مرة أخرى");
      setBusy(false);
      return;
    }
    if (result.redirected) return;
    setBusy(false);
  };

  return (
    <div dir="rtl" className="flex min-h-screen items-center justify-center bg-background px-4 py-10 font-sans text-foreground">
      <div className="w-full max-w-md rounded-3xl border border-border bg-card p-6 shadow-xl">
        <div className="mb-6 flex flex-col items-center gap-2 text-center">
          <span className="brand-mark">ت</span>
          <h1 className="text-2xl font-black">تاجر</h1>
          <p className="text-sm text-muted-foreground">
            {mode === "login" ? "سجّل دخولك لمتابعة سوقك" : "أنشئ حسابك وابدأ البيع والشراء"}
          </p>
        </div>

        <div className="mb-5 grid grid-cols-2 gap-1 rounded-xl bg-muted p-1 text-sm font-bold">
          <button
            type="button"
            onClick={() => setMode("login")}
            className={`rounded-lg py-2 transition ${mode === "login" ? "bg-background text-foreground shadow" : "text-muted-foreground"}`}
          >
            دخول
          </button>
          <button
            type="button"
            onClick={() => setMode("signup")}
            className={`rounded-lg py-2 transition ${mode === "signup" ? "bg-background text-foreground shadow" : "text-muted-foreground"}`}
          >
            حساب جديد
          </button>
        </div>

        <form onSubmit={submit} className="space-y-3">
          {mode === "signup" && (
            <label className="flex items-center gap-2 rounded-xl border border-input bg-background px-3 py-3">
              <UserRound size={18} className="text-muted-foreground" />
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="الاسم الكامل"
                className="w-full bg-transparent text-sm outline-none"
                autoComplete="name"
              />
            </label>
          )}
          <label className="flex items-center gap-2 rounded-xl border border-input bg-background px-3 py-3">
            <Mail size={18} className="text-muted-foreground" />
            <input
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              type="email"
              required
              placeholder="البريد الإلكتروني"
              className="w-full bg-transparent text-sm outline-none"
              autoComplete="email"
              dir="ltr"
            />
          </label>
          <label className="flex items-center gap-2 rounded-xl border border-input bg-background px-3 py-3">
            <Lock size={18} className="text-muted-foreground" />
            <input
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              type="password"
              required
              minLength={6}
              placeholder="كلمة المرور"
              className="w-full bg-transparent text-sm outline-none"
              autoComplete={mode === "login" ? "current-password" : "new-password"}
              dir="ltr"
            />
          </label>

          {error && <p className="rounded-lg bg-destructive/10 px-3 py-2 text-xs font-bold text-destructive">{error}</p>}

          <Button type="submit" size="lg" disabled={busy} className="h-12 w-full rounded-xl text-base">
            {busy && <Loader2 className="animate-spin" />}
            {mode === "login" ? "تسجيل الدخول" : "إنشاء الحساب"}
          </Button>
        </form>

        <div className="my-4 flex items-center gap-3 text-xs text-muted-foreground">
          <span className="h-px flex-1 bg-border" />أو<span className="h-px flex-1 bg-border" />
        </div>

        <Button variant="outline" size="lg" disabled={busy} onClick={googleSignIn} className="h-12 w-full rounded-xl text-base">
          <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true">
            <path fill="#4285F4" d="M23.5 12.3c0-.8-.1-1.6-.2-2.3H12v4.5h6.4a5.5 5.5 0 0 1-2.4 3.6v3h3.9c2.3-2.1 3.6-5.2 3.6-8.8z" />
            <path fill="#34A853" d="M12 24c3.2 0 5.9-1.1 7.9-2.9l-3.9-3a7.2 7.2 0 0 1-10.7-3.8H1.3v3.1A12 12 0 0 0 12 24z" />
            <path fill="#FBBC05" d="M5.3 14.3a7.2 7.2 0 0 1 0-4.6V6.6H1.3a12 12 0 0 0 0 10.8l4-3.1z" />
            <path fill="#EA4335" d="M12 4.8c1.8 0 3.4.6 4.6 1.8l3.4-3.4A12 12 0 0 0 1.3 6.6l4 3.1A7.2 7.2 0 0 1 12 4.8z" />
          </svg>
          المتابعة عبر جوجل
        </Button>

        <p className="mt-4 text-center text-xs text-muted-foreground">
          الدخول محفوظ على جهازك، ما تحتاج رابط بعد اليوم.
        </p>
      </div>
    </div>
  );
}
